#!/usr/bin/env python

import generators
from configgen.generators.Generator import Generator
import Command as Command
import os
import shutil
import stat
from os import path
import batoceraFiles as batoceraFiles
from xml.dom import minidom
import codecs
import controllersConfig as controllersConfig
import configparser
from shutil import copyfile
from utils.logger import get_logger

eslog = get_logger(__name__)

class WIIUPLUSGenerator(Generator):

    def generate(self, system, rom, playersControllers, gameResolution):
        #handles chmod so you just need to download cemu.AppImage
        if os.path.exists("/userdata/system/pro/wiiuplus/cemu/cemu.AppImage"):
            st = os.stat("/userdata/system/pro/wiiuplus/cemu/cemu.AppImage")
            os.chmod("/userdata/system/pro/wiiuplus/cemu/cemu.AppImage", st.st_mode | stat.S_IEXEC)

        if os.path.exists("/userdata/system/pro/wiiuplus/launcher.sh"):
            st = os.stat("/userdata/system/pro/wiiuplus/launcher.sh")
            os.chmod("/userdata/system/pro/wiiuplus/launcher.sh", st.st_mode | stat.S_IEXEC)
        
        wiiuplusConfig = '/userdata/system/pro/wiiuplus/cemu/.config1'
        beforewiiuplusConfig = '/userdata/system/pro/wiiuplus/cemu/.config0'
        
        WIIUPLUSGenerator.writeWIIUPLUSConfig(wiiuplusConfig,beforewiiuplusConfig, system, playersControllers)
        commandArray = ["/userdata/system/pro/wiiuplus/launcher.sh", rom ]

        return Command.Command(
            array=commandArray,
            env={"QT_QPA_PLATFORM":"xcb","SDL_GAMECONTROLLERCONFIG": controllersConfig.generateSdlGameControllerConfig(playersControllers) }
            )


    # @staticmethod
    def writeWIIUPLUSConfig(wiiuplusConfigFile, beforewiiuplusConfigFile, system, playersControllers):
        # pads
        wiiuplusButtons = {
            "button_a":      "a",
            "button_b":      "b",
            "button_x":      "x",
            "button_y":      "y",
            "button_dup":     "up",
            "button_ddown":   "down",
            "button_dleft":   "left",
            "button_dright":  "right",
            "button_l":      "pageup",
            "button_r":      "pagedown",
            "button_plus":  "start",
            "button_minus": "select",
            "button_sl":     "pageup",
            "button_sr":     "pagedown",
            "button_zl":     "l2",
            "button_zr":     "r2",
            "button_lstick":     "l3",
            "button_rstick":     "r3",
            "button_home":   "hotkey"
        }

        wiiuplusAxis = {
            "lstick":    "joystick1",
            "rstick":    "joystick2"
        }


        wiiuplusDSButtons = {
            "button_a":      1,
            "button_b":      0,
            "button_x":      3,
            "button_y":      2,
            "button_dup":     11,
            "button_ddown":   12,
            "button_dleft":   13,
            "button_dright":  14,
            "button_l":      9,
            "button_r":      10,
            "button_plus":  6,
            "button_minus": 4,
            "button_sl":     9,
            "button_sr":     10,
            "button_lstick":     7,
            "button_rstick":     8,
            "button_home":   5
        }

        wiiuplusDSAxis = {
            "lstick":    0,
            "rstick":    2,
            "button_zl":     4,
            "button_zr":     5
        }

        wiiuplusSCButtons = {
            "button_a":      6,
            "button_b":     5,
            "button_x":      8,
            "button_y":      7,
            "button_dup":     20,
            "button_ddown":   21,
            "button_dleft":   22,
            "button_dright":  23,
            "button_l":      9,
            "button_r":      10,
            "button_plus":  14,
            "button_minus": 13,
            #"button_zl":     18,
            #"button_zr":     10,
            "button_lstick":     16,
            "button_rstick":     17,
            "button_home":   13
        }

        wiiuplusSCAxis = {
            "lstick":    1,
            "rstick":    4,
            "button_zl":     2,
            "button_zr":     5
        }

        wiiuplusSCButtons2 = {
            "button_a":      4,
            "button_b":     5,
            "button_x":      6,
            "button_y":      7,
            "button_dup":     19,
            "button_ddown":   20,
            "button_dleft":   21,
            "button_dright":  22,
            "button_l":      8,
            "button_r":      10,
            "button_plus":  13,
            "button_minus": 12,
            #"button_zl":     18,
            #"button_zr":     10,
            "button_lstick":     15,
            "button_rstick":     16,
            "button_home":   23
        }

        wiiuplusSCAxis2 = {
            "lstick":    1,
            "rstick":    4,
            "button_zl":     2,
            "button_zr":     5
        }


        # ini file
        wiiuplusConfig = configparser.RawConfigParser()
        wiiuplusConfig.optionxform=str
        if os.path.exists(wiiuplusConfigFile):
            wiiuplusConfig.read(wiiuplusConfigFile)

        
    # UI section
        if not wiiuplusConfig.has_section("UI"):
            wiiuplusConfig.add_section("UI")
        
        wiiuplusConfig.set("UI", "fullscreen", "true")
        wiiuplusConfig.set("UI", "fullscreen\\default", "false")
        wiiuplusConfig.set("UI", "confirmClose", "false")
        wiiuplusConfig.set("UI", "confirmClose\\default", "false")
        wiiuplusConfig.set("UI", "firstStart", "false")
        wiiuplusConfig.set("UI", "firstStart\\default", "false")
        wiiuplusConfig.set("UI", "displayTitleBars", "false")
        wiiuplusConfig.set("UI", "displayTitleBars\\default", "false")

        if system.isOptSet('wiiuplus_enable_discord_presence'):
            wiiuplusConfig.set("UI", "enable_discord_presence", system.config["wiiuplus_enable_discord_presence"])
        else:
            wiiuplusConfig.set("UI", "enable_discord_presence", "false")

        wiiuplusConfig.set("UI", "enable_discord_presence\\default", "false")



        wiiuplusConfig.set("UI", "calloutFlags", "1")
        wiiuplusConfig.set("UI", "calloutFlags\\default", "false")

        # Single Window Mode
        if system.isOptSet('single_window'):
            wiiuplusConfig.set("UI", "singleWindowMode", system.config["single_window"])
            wiiuplusConfig.set("UI", "singleWindowMode\\default", "false")
        else:
            wiiuplusConfig.set("UI", "singleWindowMode", "true")
            wiiuplusConfig.set("UI", "singleWindowMode\\default", "true")

        wiiuplusConfig.set("UI", "hideInactiveMouse", "true")
        wiiuplusConfig.set("UI", "hideInactiveMouse\\default", "true")

        # Roms path (need for load update/dlc)
        wiiuplusConfig.set("UI", "Paths\\gamedirs\\1\\deep_scan", "true")
        wiiuplusConfig.set("UI", "Paths\\gamedirs\\1\\deep_scan\\default", "false")
        wiiuplusConfig.set("UI", "Paths\\gamedirs\\1\\expanded", "true")
        wiiuplusConfig.set("UI", "Paths\\gamedirs\\1\\expanded\\default", "true")
        wiiuplusConfig.set("UI", "Paths\\gamedirs\\1\\path", "/userdata/roms/switch")
        wiiuplusConfig.set("UI", "Paths\\gamedirs\\size", "1")

        wiiuplusConfig.set("UI", "Screenshots\\enable_screenshot_save_as", "true")
        wiiuplusConfig.set("UI", "Screenshots\\enable_screenshot_save_as\\default", "true")
        wiiuplusConfig.set("UI", "Screenshots\\screenshot_path", "/userdata/screenshots")
        wiiuplusConfig.set("UI", "Screenshots\\screenshot_path\\default", "false")

    # Data Storage section
        if not wiiuplusConfig.has_section("Data%20Storage"):
            wiiuplusConfig.add_section("Data%20Storage")
        wiiuplusConfig.set("Data%20Storage", "dump_directory", "/userdata/system/configs/wiiuplus/dump")
        wiiuplusConfig.set("Data%20Storage", "dump_directory\\default", "true")

        wiiuplusConfig.set("Data%20Storage", "load_directory", "/userdata/system/configs/wiiuplus/load")
        wiiuplusConfig.set("Data%20Storage", "load_directory\\default", "true")

        wiiuplusConfig.set("Data%20Storage", "nand_directory", "/userdata/system/configs/wiiuplus/nand")
        wiiuplusConfig.set("Data%20Storage", "nand_directory\\default", "true")

        wiiuplusConfig.set("Data%20Storage", "sdmc_directory", "/userdata/system/configs/wiiuplus/sdmc")
        wiiuplusConfig.set("Data%20Storage", "sdmc_directory\\default", "true")

        wiiuplusConfig.set("Data%20Storage", "tas_directory", "/userdata/system/configs/wiiuplus/tas")
        wiiuplusConfig.set("Data%20Storage", "tas_directory\\default", "true")

        wiiuplusConfig.set("Data%20Storage", "use_virtual_sd", "true")
        wiiuplusConfig.set("Data%20Storage", "use_virtual_sd\\default", "true")

    # Core section
        if not wiiuplusConfig.has_section("Core"):
            wiiuplusConfig.add_section("Core")

        # Multicore
        if system.isOptSet('multicore'):
            wiiuplusConfig.set("Core", "use_multi_core", system.config["multicore"])
            wiiuplusConfig.set("Core", "use_multi_core\\default", "false")
        else:
            wiiuplusConfig.set("Core", "use_multi_core", "true")
            wiiuplusConfig.set("Core", "use_multi_core\\default", "true")

    # Renderer section
        if not wiiuplusConfig.has_section("Renderer"):
            wiiuplusConfig.add_section("Renderer")

        # Aspect ratio
        if system.isOptSet('wiiuplus_ratio'):
            wiiuplusConfig.set("Renderer", "aspect_ratio", system.config["wiiuplus_ratio"])
            wiiuplusConfig.set("Renderer", "aspect_ratio\\default", "false")
        else:
            wiiuplusConfig.set("Renderer", "aspect_ratio", "0")
            wiiuplusConfig.set("Renderer", "aspect_ratio\\default", "true")

        # Graphical backend
        if system.isOptSet('wiiuplus_backend'):
            wiiuplusConfig.set("Renderer", "backend", system.config["wiiuplus_backend"])
        else:
            wiiuplusConfig.set("Renderer", "backend", "0")
        wiiuplusConfig.set("Renderer", "backend\\default", "false")

        # Async Shader compilation
        if system.isOptSet('async_shaders'):
            wiiuplusConfig.set("Renderer", "use_asynchronous_shaders", system.config["async_shaders"])
        else:
            wiiuplusConfig.set("Renderer", "use_asynchronous_shaders", "true")
        wiiuplusConfig.set("Renderer", "use_asynchronous_shaders\\default", "false")

        # Assembly shaders
        if system.isOptSet('shaderbackend'):
            wiiuplusConfig.set("Renderer", "shader_backend", system.config["shaderbackend"])
            wiiuplusConfig.set("Renderer", "shader_backend\\default", "false")
        else:
            wiiuplusConfig.set("Renderer", "shader_backend", "0")
            wiiuplusConfig.set("Renderer", "shader_backend\\default", "true")

        # Async Gpu Emulation
        if system.isOptSet('async_gpu'):
            wiiuplusConfig.set("Renderer", "use_asynchronous_gpu_emulation", system.config["async_gpu"])
            wiiuplusConfig.set("Renderer", "use_asynchronous_gpu_emulation\\default", "false")
        else:
            wiiuplusConfig.set("Renderer", "use_asynchronous_gpu_emulation", "true")
            wiiuplusConfig.set("Renderer", "use_asynchronous_gpu_emulation\\default", "true")

        # NVDEC Emulation
        if system.isOptSet('nvdec_emu'):
            wiiuplusConfig.set("Renderer", "nvdec_emulation", system.config["nvdec_emu"])
            wiiuplusConfig.set("Renderer", "nvdec_emulation\\default", "false")
        else:
            wiiuplusConfig.set("Renderer", "nvdec_emulation", "2")
            wiiuplusConfig.set("Renderer", "nvdec_emulation\\default", "true")

        # Gpu Accuracy
        if system.isOptSet('gpuaccuracy'):
            wiiuplusConfig.set("Renderer", "gpu_accuracy", system.config["gpuaccuracy"])
        else:
            wiiuplusConfig.set("Renderer", "gpu_accuracy", "0")
        wiiuplusConfig.set("Renderer", "gpu_accuracy\\default", "false")

        # Vsync
        if system.isOptSet('vsync'):
            wiiuplusConfig.set("Renderer", "use_vsync", system.config["vsync"])
        else:
            wiiuplusConfig.set("Renderer", "use_vsync", "false")
        wiiuplusConfig.set("Renderer", "use_vsync\\default", "false")

        # Gpu cache garbage collection
        if system.isOptSet('gpu_cache_gc'):
            wiiuplusConfig.set("Renderer", "use_caches_gc", system.config["gpu_cache_gc"])
        else:
            wiiuplusConfig.set("Renderer", "use_caches_gc", "false")
        wiiuplusConfig.set("Renderer", "use_caches_gc\\default", "false")

        # Max anisotropy
        if system.isOptSet('anisotropy'):
            wiiuplusConfig.set("Renderer", "max_anisotropy", system.config["anisotropy"])
            wiiuplusConfig.set("Renderer", "max_anisotropy\\default", "false")
        else:
            wiiuplusConfig.set("Renderer", "max_anisotropy", "0")
            wiiuplusConfig.set("Renderer", "max_anisotropy\\default", "true")

        # Resolution scaler
        if system.isOptSet('resolution_scale'):
            wiiuplusConfig.set("Renderer", "resolution_setup", system.config["resolution_scale"])
            wiiuplusConfig.set("Renderer", "resolution_setup\\default", "false")
        else:
            wiiuplusConfig.set("Renderer", "resolution_setup", "2")
            wiiuplusConfig.set("Renderer", "resolution_setup\\default", "true")

        # Scaling filter
        if system.isOptSet('scale_filter'):
            wiiuplusConfig.set("Renderer", "scaling_filter", system.config["scale_filter"])
            wiiuplusConfig.set("Renderer", "scaling_filter\\default", "false")
        else:
            wiiuplusConfig.set("Renderer", "scaling_filter", "1")
            wiiuplusConfig.set("Renderer", "scaling_filter\\default", "true")

        # Anti aliasing method
        if system.isOptSet('aliasing_method'):
            wiiuplusConfig.set("Renderer", "anti_aliasing", system.config["aliasing_method"])
            wiiuplusConfig.set("Renderer", "anti_aliasing\\default", "false")
        else:
            wiiuplusConfig.set("Renderer", "anti_aliasing", "0")
            wiiuplusConfig.set("Renderer", "anti_aliasing\\default", "true")

    # Cpu Section
        if not wiiuplusConfig.has_section("Cpu"):
            wiiuplusConfig.add_section("Cpu")

        # Cpu Accuracy
        if system.isOptSet('cpuaccuracy'):
            wiiuplusConfig.set("Cpu", "cpu_accuracy", system.config["cpuaccuracy"])
            wiiuplusConfig.set("Cpu", "cpu_accuracy\\default", "false")
        else:
            wiiuplusConfig.set("Cpu", "cpu_accuracy", "0")
            wiiuplusConfig.set("Cpu", "cpu_accuracy\\default", "true")

    # System section
        if not wiiuplusConfig.has_section("System"):
            wiiuplusConfig.add_section("System")

        # Language
        if system.isOptSet('language'):
            wiiuplusConfig.set("System", "language_index", system.config["language"])
            wiiuplusConfig.set("System", "language_index\\default", "false")
        else:
            wiiuplusConfig.set("System", "language_index", "1")
            wiiuplusConfig.set("System", "language_index\\default", "true")

        # Region
        if system.isOptSet('region'):
            wiiuplusConfig.set("System", "region_index", system.config["region"])
            wiiuplusConfig.set("System", "region_index\\default", "false")
        else:
            wiiuplusConfig.set("System", "region_index", "1")
            wiiuplusConfig.set("System", "region_index\\default", "true")

    # controls section
        if not wiiuplusConfig.has_section("Controls"):
            wiiuplusConfig.add_section("Controls")

        # Dock Mode
        if system.isOptSet('dock_mode'):
            wiiuplusConfig.set("Controls", "use_docked_mode", system.config["dock_mode"])
            wiiuplusConfig.set("Controls", "use_docked_mode\\default", "false")
        else:
            wiiuplusConfig.set("Controls", "use_docked_mode", "true")
            wiiuplusConfig.set("Controls", "use_docked_mode\\default", "true")


        if ((system.isOptSet('wiiuplus_auto_controller_config') and not (system.config["wiiuplus_auto_controller_config"] == "0")) or not system.isOptSet('wiiuplus_auto_controller_config')):
            # Player 1 Pad Type
            if system.isOptSet('p1_pad'):
                wiiuplusConfig.set("Controls", "player_0_type", system.config["p1_pad"])
            else:
                wiiuplusConfig.set("Controls", "player_0_type", "0")
            wiiuplusConfig.set("Controls", "player_0_type\default", "false")

            # Player 2 Pad Type
            if system.isOptSet('p2_pad'):
                wiiuplusConfig.set("Controls", "player_1_type", system.config["p2_pad"])
            else:
                wiiuplusConfig.set("Controls", "player_1_type", "0")
            
            # Player 3 Pad Type
            if system.isOptSet('p3_pad'):
                wiiuplusConfig.set("Controls", "player_2_type", system.config["p3_pad"])
            else:
                wiiuplusConfig.set("Controls", "player_2_type", "0")

            # Player 4 Pad Type
            if system.isOptSet('p4_pad'):
                wiiuplusConfig.set("Controls", "player_3_type", system.config["p4_pad"])
            else:
                wiiuplusConfig.set("Controls", "player_3_type", "0")

            
            wiiuplusConfig.set("Controls", "player_1_type\default", "false")

            wiiuplusConfig.set("Controls", "vibration_enabled", "true")
            wiiuplusConfig.set("Controls", "vibration_enabled\\default", "true")

            guidstoreplace_ds4 = ["050000004c050000c405000000783f00","050000004c050000c4050000fffe3f00","050000004c050000c4050000ffff3f00","050000004c050000cc090000fffe3f00","050000004c050000cc090000ffff3f00","30303839663330346632363232623138","31326235383662333266633463653332","34613139376634626133336530386430","37626233336235343937333961353732","38393161636261653636653532386639","63313733393535663339656564343962","63393662363836383439353064663939","65366465656364636137653363376531","66613532303965383534396638613230","050000004c050000cc090000df070000","050000004c050000cc090000df870001","050000004c050000cc090000ff070000","030000004c050000a00b000011010000","030000004c050000a00b000011810000","030000004c050000c405000011010000","030000004c050000c405000011810000","030000004c050000cc09000000010000","030000004c050000cc09000011010000","030000004c050000cc09000011810000","03000000c01100000140000011010000","050000004c050000c405000000010000","050000004c050000c405000000810000","050000004c050000c405000001800000","050000004c050000cc09000000010000","050000004c050000cc09000000810000","050000004c050000cc09000001800000","030000004c050000a00b000000010000","030000004c050000c405000000000000","030000004c050000c405000000010000","03000000120c00000807000000000000","03000000120c0000111e000000000000","03000000120c0000121e000000000000","03000000120c0000130e000000000000","03000000120c0000150e000000000000","03000000120c0000180e000000000000","03000000120c0000181e000000000000","03000000120c0000191e000000000000","03000000120c00001e0e000000000000","03000000120c0000a957000000000000","03000000120c0000aa57000000000000","03000000120c0000f21c000000000000","03000000120c0000f31c000000000000","03000000120c0000f41c000000000000","03000000120c0000f51c000000000000","03000000120c0000f70e000000000000","03000000120e0000120c000000000000","03000000160e0000120c000000000000","030000001a1e0000120c000000000000","030000004c050000a00b000000000000","030000004c050000cc09000000000000","35643031303033326130316330353564","31373231336561636235613666323035","536f6e7920496e746572616374697665","576972656c65737320436f6e74726f6c","050000004c050000cc090000ff870001","050000004c050000cc090000ff876d01","31663838336334393132303338353963"]
            guidstoreplace_ds5_wireless = ["32633532643734376632656664383733","37363764353731323963323639666565","61303162353165316365336436343139","050000004c050000e60c0000df870000","050000004c050000e60c000000810000","030000004c050000e60c000000010000","050000004c050000e60c0000fffe3f00","030000004c050000e60c000000000000","050000004c050000e60c000000010000","030000004c050000e60c000011010000","32346465346533616263386539323932","050000004c050000e60c0000ff870000"]
            guidstoreplace_ds5_wired = ["030000004c050000e60c000011810000"]
            guidstoreplace_xbox = ["050000005e040000fd02000030110000"]
            guidstoreplace_steam = ["03000000de2800000512000010010000"]
            guidstoreplace_steam2 = ["03000000de2800000512000011010000"]

            cguid = [0 for x in range(10)]
            lastplayer = 0
            for index in playersControllers :
                controller = playersControllers[index]
                portnumber = cguid.count(controller.guid)
                controllernumber = str(int(controller.player) - 1)
                cguid[int(controllernumber)] = controller.guid
                inputguid = controller.guid
                #DS4 GUIDs from https://github.com/gabomdq/SDL_GameControllerDB/blob/master/gamecontrollerdb.txt
                if controller.guid in guidstoreplace_ds4:
                    inputguid = "030000004c050000cc09000000006800"
                #DS5 GUIDs from https://github.com/gabomdq/SDL_GameControllerDB/blob/master/gamecontrollerdb.txt
                if controller.guid in guidstoreplace_ds5_wireless:
                    inputguid = "030000004c050000e60c000000006800"
                if controller.guid in guidstoreplace_ds5_wired:
                    inputguid = "030000004c050000e60c000000016800"
                if controller.guid in guidstoreplace_xbox:
                    inputguid = "050000005e040000fd02000030110000"
                #DS5 corrections
                if ((controller.guid in guidstoreplace_ds5_wireless) or (controller.guid in guidstoreplace_ds4) or (controller.guid in guidstoreplace_ds5_wired)) :
                    #button_a="engine:sdl,port:0,guid:030000004c050000e60c000000006800,button:1"
                    for x in wiiuplusDSButtons:
                        wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},button:{}"'.format(portnumber,inputguid,wiiuplusDSButtons[x]))
                    for x in wiiuplusDSAxis:
                        if(x == "button_zl" or x == "button_zr"):
                            wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,invert:+,port:{},guid:{},axis:{},threshold:0.500000"'.format(portnumber,inputguid,wiiuplusDSAxis[x]))
                        else:
                            wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},axis_x:{},offset_x:-0.011750,axis_y:{},offset_y:-0.027467,invert_x:+,invert_y:+,deadzone:0.150000,range:0.950000"'.format(portnumber,inputguid,wiiuplusDSAxis[x],wiiuplusDSAxis[x]+1))
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                elif (controller.guid in guidstoreplace_steam) :
                    #button_a="engine:sdl,port:0,guid:030000004c050000e60c000000006800,button:1"
                    for x in wiiuplusSCButtons:
                        wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},button:{}"'.format(portnumber,inputguid,wiiuplusSCButtons[x]))
                    for x in wiiuplusSCAxis:
                        if(x == "button_zl" or x == "button_zr"):
                            wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,invert:+,port:{},guid:{},axis:{},threshold:0.500000"'.format(portnumber,inputguid,wiiuplusSCAxis[x]))
                        else:
                            wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},axis_x:{},offset_x:-0.011750,axis_y:{},offset_y:-0.027467,invert_x:+,invert_y:+,deadzone:0.150000,range:0.950000"'.format(portnumber,inputguid,wiiuplusSCAxis[x],wiiuplusSCAxis[x]+1))
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"[empty]"')
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"[empty]"')
                    #wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                    #wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                elif (controller.guid in guidstoreplace_steam2) :
                    #button_a="engine:sdl,port:0,guid:030000004c050000e60c000000006800,button:1"
                    for x in wiiuplusSCButtons2:
                        wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},button:{}"'.format(portnumber,inputguid,wiiuplusSCButtons2[x]))
                    for x in wiiuplusSCAxis2:
                        if(x == "button_zl" or x == "button_zr"):
                            wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,invert:+,port:{},guid:{},axis:{},threshold:0.500000"'.format(portnumber,inputguid,wiiuplusSCAxis2[x]))
                        else:
                            wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},axis_x:{},offset_x:-0.011750,axis_y:{},offset_y:-0.027467,invert_x:+,invert_y:+,deadzone:0.150000,range:0.950000"'.format(portnumber,inputguid,wiiuplusSCAxis2[x],wiiuplusSCAxis2[x]+1))
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"[empty]"')
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"[empty]"')
                    #wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                    #wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                else:
                    for x in wiiuplusButtons:
                        wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"{}"'.format(WIIUPLUSGenerator.setButton(wiiuplusButtons[x], inputguid, controller.inputs,portnumber)))
                    for x in wiiuplusAxis:
                        wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"{}"'.format(WIIUPLUSGenerator.setAxis(wiiuplusAxis[x], inputguid, controller.inputs, portnumber)))
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '[empty]')
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_motionright", '[empty]')

                
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_connected", "true")
                if (controllernumber == "0"):
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_connected\default", "true")
                else:
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_connected\default", "false")                    
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_type", "0")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_type\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_vibration_enabled", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_vibration_enabled\\default", "true")
                lastplayer = int(controllernumber)
            lastplayer = lastplayer + 1
            eslog.debug("Last Player {}".format(lastplayer))
            for y in range(lastplayer, 9):
                controllernumber = str(y)
                eslog.debug("Setting Controller: {}".format(controllernumber))
                for x in wiiuplusButtons:
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '""')
                for x in wiiuplusDSAxis:
                    wiiuplusConfig.set("Controls", "player_" + controllernumber + "_" + x, '""')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_a", '"toggle:0,code:67,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_a\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_b", '"toggle:0,code:88,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_b\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_ddown", '"toggle:0,code:16777237,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_ddown\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_dleft", '"toggle:0,code:16777234,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_dleft\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_dright", '"toggle:0,code:16777236,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_dright\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_dup", '"toggle:0,code:16777235,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_dup\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_home", '"toggle:0,code:0,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_home\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_l", '"toggle:0,code:81,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_l\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_lstick", '"toggle:0,code:70,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_lstick\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_minus", '"toggle:0,code:78,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_minus\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_plus", '"toggle:0,code:77,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_plus\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_r", '"toggle:0,code:69,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_r\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_rstick", '"toggle:0,code:71,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_rstick\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_screenshot", '"toggle:0,code:0,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_screenshot\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_sl", '"toggle:0,code:81,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_sl\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_sr", '"toggle:0,code:69,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_sr\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_x", '"toggle:0,code:86,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_x\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_y", '"toggle:0,code:90,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_y\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_zl", '"toggle:0,code:82,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_zl\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_zr", '"toggle:0,code:84,engine:keyboard"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_button_zr\\default", "true")

                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_lstick", '"modifier_scale:0.500000,modifier:toggle$00$1code$016777248$1engine$0keyboard,right:toggle$00$1code$068$1engine$0keyboard,left:toggle$00$1code$065$1engine$0keyboard,down:toggle$00$1code$083$1engine$0keyboard,up:toggle$00$1code$087$1engine$0keyboard,engine:analog_from_button"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_lstick\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_rstick", '"modifier_scale:0.500000,modifier:toggle$00$1code$00$1engine$0keyboard,right:toggle$00$1code$076$1engine$0keyboard,left:toggle$00$1code$074$1engine$0keyboard,down:toggle$00$1code$075$1engine$0keyboard,up:toggle$00$1code$073$1engine$0keyboard,engine:analog_from_button"')
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_rstick\\default", "true")


                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_connected", "false")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_connected\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_type", "0")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_type\\default", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_vibration_enabled", "true")
                wiiuplusConfig.set("Controls", "player_" + controllernumber + "_vibration_enabled\\default", "true")


    # telemetry section
        if not wiiuplusConfig.has_section("WebService"):
            wiiuplusConfig.add_section("WebService") 
        wiiuplusConfig.set("WebService", "enable_telemetry", "false")
        wiiuplusConfig.set("WebService", "enable_telemetry\\default", "false") 
        
        
    # Services section
        if not wiiuplusConfig.has_section("Services"):
            wiiuplusConfig.add_section("Services")
        wiiuplusConfig.set("Services", "bcat_backend", "none")
        wiiuplusConfig.set("Services", "bcat_backend\\default", "none") 

        ### update the configuration file
        if not os.path.exists(os.path.dirname(wiiuplusConfigFile)):
            os.makedirs(os.path.dirname(wiiuplusConfigFile))
        with open(wiiuplusConfigFile, 'w') as configfile:
            wiiuplusConfig.write(configfile)

        with open(beforewiiuplusConfigFile, 'w') as configfile:
            wiiuplusConfig.write(configfile)

    @staticmethod
    def setButton(key, padGuid, padInputs,controllernumber):

        # it would be better to pass the joystick num instead of the guid because 2 joysticks may have the same guid
        if key in padInputs:
            input = padInputs[key]

            if input.type == "button":
                return ("engine:sdl,button:{},guid:{},port:{}").format(input.id, padGuid, controllernumber)
            elif input.type == "hat":
                return ("engine:sdl,hat:{},direction:{},guid:{},port:{}").format(input.id, WIIUPLUSGenerator.hatdirectionvalue(input.value), padGuid, controllernumber)
            elif input.type == "axis":
                # untested, need to configure an axis as button / triggers buttons to be tested too
                return ("engine:sdl,threshold:{},axis:{},guid:{},port:{},invert:{}").format(0.5, input.id, padGuid, controllernumber, "+")
                

    @staticmethod
    def setAxis(key, padGuid, padInputs,controllernumber):
        inputx = -1
        inputy = -1

        if key == "joystick1":
            try:
                inputx = padInputs["joystick1left"]
            except:
                inputx = ["0"]
        elif key == "joystick2":
            try:
                inputx = padInputs["joystick2left"]
            except:
                inputx = ["0"]

        if key == "joystick1":
            try:
                inputy = padInputs["joystick1up"]
            except:
                inputy = ["0"]
        elif key == "joystick2":
            try:
                inputy = padInputs["joystick2up"]
            except:
                inputy = ["0"]

        try:
            return ("engine:sdl,range:1.000000,deadzone:0.100000,invert_y:+,invert_x:+,offset_y:-0.000000,axis_y:{},offset_x:-0.000000,axis_x:{},guid:{},port:{}").format(inputy.id, inputx.id, padGuid, controllernumber)
        except:
            return ("0")

    @staticmethod
    def hatdirectionvalue(value):
        if int(value) == 1:
            return "up"
        if int(value) == 4:
            return "down"
        if int(value) == 2:
            return "right"
        if int(value) == 8:
            return "left"
        return "unknown"