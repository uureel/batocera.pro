#!/usr/bin/env python

import generators
from configgen.generators.Generator import Generator
import Command as Command
import os
import shutil
import stat
from os import path
import batoceraFiles as batoceraFiles
from xml.dom import minidom
import codecs
import controllersConfig as controllersConfig
import configparser
from shutil import copyfile
from utils.logger import get_logger

eslog = get_logger(__name__)

class RPCS3PLUSGenerator(Generator):

    def generate(self, system, rom, playersControllers, gameResolution):
        #handles chmod so you just need to download rpcs3plus.AppImage
        if os.path.exists("/userdata/system/pro/ps3plus/rpcs3/rpcs3.AppImage"):
            st = os.stat("/userdata/system/pro/ps3plus/rpcs3/rpcs3.AppImage")
            os.chmod("/userdata/system/pro/ps3plus/rpcs3/rpcs3.AppImage", st.st_mode | stat.S_IEXEC)

        if os.path.exists("/userdata/system/pro/ps3plus/launcher.sh"):
            st = os.stat("/userdata/system/pro/ps3plus/launcher.sh")
            os.chmod("/userdata/system/pro/ps3plus/launcher.sh", st.st_mode | stat.S_IEXEC)
        
        rpcs3plusConfig = '/userdata/system/pro/ps3plus/rpcs3/.config1'
        beforerpcs3plusConfig = '/userdata/system/pro/ps3plus/rpcs3/.config0'
        
        RPCS3PLUSGenerator.writeRPCS3PLUSConfig(rpcs3plusConfig,beforerpcs3plusConfig, system, playersControllers)
        commandArray = ["/userdata/system/pro/ps3plus/launcher.sh", rom ]

        return Command.Command(
            array=commandArray,
            env={"QT_QPA_PLATFORM":"xcb","SDL_GAMECONTROLLERCONFIG": controllersConfig.generateSdlGameControllerConfig(playersControllers) }
            )


    # @staticmethod
    def writeRPCS3PLUSConfig(rpcs3plusConfigFile, beforerpcs3plusConfigFile, system, playersControllers):
        # pads
        rpcs3plusButtons = {
            "button_a":      "a",
            "button_b":      "b",
            "button_x":      "x",
            "button_y":      "y",
            "button_dup":     "up",
            "button_ddown":   "down",
            "button_dleft":   "left",
            "button_dright":  "right",
            "button_l":      "pageup",
            "button_r":      "pagedown",
            "button_plus":  "start",
            "button_minus": "select",
            "button_sl":     "pageup",
            "button_sr":     "pagedown",
            "button_zl":     "l2",
            "button_zr":     "r2",
            "button_lstick":     "l3",
            "button_rstick":     "r3",
            "button_home":   "hotkey"
        }

        rpcs3plusAxis = {
            "lstick":    "joystick1",
            "rstick":    "joystick2"
        }


        rpcs3plusDSButtons = {
            "button_a":      1,
            "button_b":      0,
            "button_x":      3,
            "button_y":      2,
            "button_dup":     11,
            "button_ddown":   12,
            "button_dleft":   13,
            "button_dright":  14,
            "button_l":      9,
            "button_r":      10,
            "button_plus":  6,
            "button_minus": 4,
            "button_sl":     9,
            "button_sr":     10,
            "button_lstick":     7,
            "button_rstick":     8,
            "button_home":   5
        }

        rpcs3plusDSAxis = {
            "lstick":    0,
            "rstick":    2,
            "button_zl":     4,
            "button_zr":     5
        }

        rpcs3plusSCButtons = {
            "button_a":      6,
            "button_b":     5,
            "button_x":      8,
            "button_y":      7,
            "button_dup":     20,
            "button_ddown":   21,
            "button_dleft":   22,
            "button_dright":  23,
            "button_l":      9,
            "button_r":      10,
            "button_plus":  14,
            "button_minus": 13,
            #"button_zl":     18,
            #"button_zr":     10,
            "button_lstick":     16,
            "button_rstick":     17,
            "button_home":   13
        }

        rpcs3plusSCAxis = {
            "lstick":    1,
            "rstick":    4,
            "button_zl":     2,
            "button_zr":     5
        }

        rpcs3plusSCButtons2 = {
            "button_a":      4,
            "button_b":     5,
            "button_x":      6,
            "button_y":      7,
            "button_dup":     19,
            "button_ddown":   20,
            "button_dleft":   21,
            "button_dright":  22,
            "button_l":      8,
            "button_r":      10,
            "button_plus":  13,
            "button_minus": 12,
            #"button_zl":     18,
            #"button_zr":     10,
            "button_lstick":     15,
            "button_rstick":     16,
            "button_home":   23
        }

        rpcs3plusSCAxis2 = {
            "lstick":    1,
            "rstick":    4,
            "button_zl":     2,
            "button_zr":     5
        }


        # ini file
        rpcs3plusConfig = configparser.RawConfigParser()
        rpcs3plusConfig.optionxform=str
        if os.path.exists(rpcs3plusConfigFile):
            rpcs3plusConfig.read(rpcs3plusConfigFile)

        
    # UI section
        if not rpcs3plusConfig.has_section("UI"):
            rpcs3plusConfig.add_section("UI")
        
        rpcs3plusConfig.set("UI", "fullscreen", "true")
        rpcs3plusConfig.set("UI", "fullscreen\\default", "false")
        rpcs3plusConfig.set("UI", "confirmClose", "false")
        rpcs3plusConfig.set("UI", "confirmClose\\default", "false")
        rpcs3plusConfig.set("UI", "firstStart", "false")
        rpcs3plusConfig.set("UI", "firstStart\\default", "false")
        rpcs3plusConfig.set("UI", "displayTitleBars", "false")
        rpcs3plusConfig.set("UI", "displayTitleBars\\default", "false")

        if system.isOptSet('rpcs3plus_enable_discord_presence'):
            rpcs3plusConfig.set("UI", "enable_discord_presence", system.config["rpcs3plus_enable_discord_presence"])
        else:
            rpcs3plusConfig.set("UI", "enable_discord_presence", "false")

        rpcs3plusConfig.set("UI", "enable_discord_presence\\default", "false")



        rpcs3plusConfig.set("UI", "calloutFlags", "1")
        rpcs3plusConfig.set("UI", "calloutFlags\\default", "false")

        # Single Window Mode
        if system.isOptSet('single_window'):
            rpcs3plusConfig.set("UI", "singleWindowMode", system.config["single_window"])
            rpcs3plusConfig.set("UI", "singleWindowMode\\default", "false")
        else:
            rpcs3plusConfig.set("UI", "singleWindowMode", "true")
            rpcs3plusConfig.set("UI", "singleWindowMode\\default", "true")

        rpcs3plusConfig.set("UI", "hideInactiveMouse", "true")
        rpcs3plusConfig.set("UI", "hideInactiveMouse\\default", "true")

        # Roms path (need for load update/dlc)
        rpcs3plusConfig.set("UI", "Paths\\gamedirs\\1\\deep_scan", "true")
        rpcs3plusConfig.set("UI", "Paths\\gamedirs\\1\\deep_scan\\default", "false")
        rpcs3plusConfig.set("UI", "Paths\\gamedirs\\1\\expanded", "true")
        rpcs3plusConfig.set("UI", "Paths\\gamedirs\\1\\expanded\\default", "true")
        rpcs3plusConfig.set("UI", "Paths\\gamedirs\\1\\path", "/userdata/roms/switch")
        rpcs3plusConfig.set("UI", "Paths\\gamedirs\\size", "1")

        rpcs3plusConfig.set("UI", "Screenshots\\enable_screenshot_save_as", "true")
        rpcs3plusConfig.set("UI", "Screenshots\\enable_screenshot_save_as\\default", "true")
        rpcs3plusConfig.set("UI", "Screenshots\\screenshot_path", "/userdata/screenshots")
        rpcs3plusConfig.set("UI", "Screenshots\\screenshot_path\\default", "false")

    # Data Storage section
        if not rpcs3plusConfig.has_section("Data%20Storage"):
            rpcs3plusConfig.add_section("Data%20Storage")
        rpcs3plusConfig.set("Data%20Storage", "dump_directory", "/userdata/system/configs/rpcs3plus/dump")
        rpcs3plusConfig.set("Data%20Storage", "dump_directory\\default", "true")

        rpcs3plusConfig.set("Data%20Storage", "load_directory", "/userdata/system/configs/rpcs3plus/load")
        rpcs3plusConfig.set("Data%20Storage", "load_directory\\default", "true")

        rpcs3plusConfig.set("Data%20Storage", "nand_directory", "/userdata/system/configs/rpcs3plus/nand")
        rpcs3plusConfig.set("Data%20Storage", "nand_directory\\default", "true")

        rpcs3plusConfig.set("Data%20Storage", "sdmc_directory", "/userdata/system/configs/rpcs3plus/sdmc")
        rpcs3plusConfig.set("Data%20Storage", "sdmc_directory\\default", "true")

        rpcs3plusConfig.set("Data%20Storage", "tas_directory", "/userdata/system/configs/rpcs3plus/tas")
        rpcs3plusConfig.set("Data%20Storage", "tas_directory\\default", "true")

        rpcs3plusConfig.set("Data%20Storage", "use_virtual_sd", "true")
        rpcs3plusConfig.set("Data%20Storage", "use_virtual_sd\\default", "true")

    # Core section
        if not rpcs3plusConfig.has_section("Core"):
            rpcs3plusConfig.add_section("Core")

        # Multicore
        if system.isOptSet('multicore'):
            rpcs3plusConfig.set("Core", "use_multi_core", system.config["multicore"])
            rpcs3plusConfig.set("Core", "use_multi_core\\default", "false")
        else:
            rpcs3plusConfig.set("Core", "use_multi_core", "true")
            rpcs3plusConfig.set("Core", "use_multi_core\\default", "true")

    # Renderer section
        if not rpcs3plusConfig.has_section("Renderer"):
            rpcs3plusConfig.add_section("Renderer")

        # Aspect ratio
        if system.isOptSet('rpcs3plus_ratio'):
            rpcs3plusConfig.set("Renderer", "aspect_ratio", system.config["rpcs3plus_ratio"])
            rpcs3plusConfig.set("Renderer", "aspect_ratio\\default", "false")
        else:
            rpcs3plusConfig.set("Renderer", "aspect_ratio", "0")
            rpcs3plusConfig.set("Renderer", "aspect_ratio\\default", "true")

        # Graphical backend
        if system.isOptSet('rpcs3plus_backend'):
            rpcs3plusConfig.set("Renderer", "backend", system.config["rpcs3plus_backend"])
        else:
            rpcs3plusConfig.set("Renderer", "backend", "0")
        rpcs3plusConfig.set("Renderer", "backend\\default", "false")

        # Async Shader compilation
        if system.isOptSet('async_shaders'):
            rpcs3plusConfig.set("Renderer", "use_asynchronous_shaders", system.config["async_shaders"])
        else:
            rpcs3plusConfig.set("Renderer", "use_asynchronous_shaders", "true")
        rpcs3plusConfig.set("Renderer", "use_asynchronous_shaders\\default", "false")

        # Assembly shaders
        if system.isOptSet('shaderbackend'):
            rpcs3plusConfig.set("Renderer", "shader_backend", system.config["shaderbackend"])
            rpcs3plusConfig.set("Renderer", "shader_backend\\default", "false")
        else:
            rpcs3plusConfig.set("Renderer", "shader_backend", "0")
            rpcs3plusConfig.set("Renderer", "shader_backend\\default", "true")

        # Async Gpu Emulation
        if system.isOptSet('async_gpu'):
            rpcs3plusConfig.set("Renderer", "use_asynchronous_gpu_emulation", system.config["async_gpu"])
            rpcs3plusConfig.set("Renderer", "use_asynchronous_gpu_emulation\\default", "false")
        else:
            rpcs3plusConfig.set("Renderer", "use_asynchronous_gpu_emulation", "true")
            rpcs3plusConfig.set("Renderer", "use_asynchronous_gpu_emulation\\default", "true")

        # NVDEC Emulation
        if system.isOptSet('nvdec_emu'):
            rpcs3plusConfig.set("Renderer", "nvdec_emulation", system.config["nvdec_emu"])
            rpcs3plusConfig.set("Renderer", "nvdec_emulation\\default", "false")
        else:
            rpcs3plusConfig.set("Renderer", "nvdec_emulation", "2")
            rpcs3plusConfig.set("Renderer", "nvdec_emulation\\default", "true")

        # Gpu Accuracy
        if system.isOptSet('gpuaccuracy'):
            rpcs3plusConfig.set("Renderer", "gpu_accuracy", system.config["gpuaccuracy"])
        else:
            rpcs3plusConfig.set("Renderer", "gpu_accuracy", "0")
        rpcs3plusConfig.set("Renderer", "gpu_accuracy\\default", "false")

        # Vsync
        if system.isOptSet('vsync'):
            rpcs3plusConfig.set("Renderer", "use_vsync", system.config["vsync"])
        else:
            rpcs3plusConfig.set("Renderer", "use_vsync", "false")
        rpcs3plusConfig.set("Renderer", "use_vsync\\default", "false")

        # Gpu cache garbage collection
        if system.isOptSet('gpu_cache_gc'):
            rpcs3plusConfig.set("Renderer", "use_caches_gc", system.config["gpu_cache_gc"])
        else:
            rpcs3plusConfig.set("Renderer", "use_caches_gc", "false")
        rpcs3plusConfig.set("Renderer", "use_caches_gc\\default", "false")

        # Max anisotropy
        if system.isOptSet('anisotropy'):
            rpcs3plusConfig.set("Renderer", "max_anisotropy", system.config["anisotropy"])
            rpcs3plusConfig.set("Renderer", "max_anisotropy\\default", "false")
        else:
            rpcs3plusConfig.set("Renderer", "max_anisotropy", "0")
            rpcs3plusConfig.set("Renderer", "max_anisotropy\\default", "true")

        # Resolution scaler
        if system.isOptSet('resolution_scale'):
            rpcs3plusConfig.set("Renderer", "resolution_setup", system.config["resolution_scale"])
            rpcs3plusConfig.set("Renderer", "resolution_setup\\default", "false")
        else:
            rpcs3plusConfig.set("Renderer", "resolution_setup", "2")
            rpcs3plusConfig.set("Renderer", "resolution_setup\\default", "true")

        # Scaling filter
        if system.isOptSet('scale_filter'):
            rpcs3plusConfig.set("Renderer", "scaling_filter", system.config["scale_filter"])
            rpcs3plusConfig.set("Renderer", "scaling_filter\\default", "false")
        else:
            rpcs3plusConfig.set("Renderer", "scaling_filter", "1")
            rpcs3plusConfig.set("Renderer", "scaling_filter\\default", "true")

        # Anti aliasing method
        if system.isOptSet('aliasing_method'):
            rpcs3plusConfig.set("Renderer", "anti_aliasing", system.config["aliasing_method"])
            rpcs3plusConfig.set("Renderer", "anti_aliasing\\default", "false")
        else:
            rpcs3plusConfig.set("Renderer", "anti_aliasing", "0")
            rpcs3plusConfig.set("Renderer", "anti_aliasing\\default", "true")

    # Cpu Section
        if not rpcs3plusConfig.has_section("Cpu"):
            rpcs3plusConfig.add_section("Cpu")

        # Cpu Accuracy
        if system.isOptSet('cpuaccuracy'):
            rpcs3plusConfig.set("Cpu", "cpu_accuracy", system.config["cpuaccuracy"])
            rpcs3plusConfig.set("Cpu", "cpu_accuracy\\default", "false")
        else:
            rpcs3plusConfig.set("Cpu", "cpu_accuracy", "0")
            rpcs3plusConfig.set("Cpu", "cpu_accuracy\\default", "true")

    # System section
        if not rpcs3plusConfig.has_section("System"):
            rpcs3plusConfig.add_section("System")

        # Language
        if system.isOptSet('language'):
            rpcs3plusConfig.set("System", "language_index", system.config["language"])
            rpcs3plusConfig.set("System", "language_index\\default", "false")
        else:
            rpcs3plusConfig.set("System", "language_index", "1")
            rpcs3plusConfig.set("System", "language_index\\default", "true")

        # Region
        if system.isOptSet('region'):
            rpcs3plusConfig.set("System", "region_index", system.config["region"])
            rpcs3plusConfig.set("System", "region_index\\default", "false")
        else:
            rpcs3plusConfig.set("System", "region_index", "1")
            rpcs3plusConfig.set("System", "region_index\\default", "true")

    # controls section
        if not rpcs3plusConfig.has_section("Controls"):
            rpcs3plusConfig.add_section("Controls")

        # Dock Mode
        if system.isOptSet('dock_mode'):
            rpcs3plusConfig.set("Controls", "use_docked_mode", system.config["dock_mode"])
            rpcs3plusConfig.set("Controls", "use_docked_mode\\default", "false")
        else:
            rpcs3plusConfig.set("Controls", "use_docked_mode", "true")
            rpcs3plusConfig.set("Controls", "use_docked_mode\\default", "true")


        if ((system.isOptSet('rpcs3plus_auto_controller_config') and not (system.config["rpcs3plus_auto_controller_config"] == "0")) or not system.isOptSet('rpcs3plus_auto_controller_config')):
            # Player 1 Pad Type
            if system.isOptSet('p1_pad'):
                rpcs3plusConfig.set("Controls", "player_0_type", system.config["p1_pad"])
            else:
                rpcs3plusConfig.set("Controls", "player_0_type", "0")
            rpcs3plusConfig.set("Controls", "player_0_type\default", "false")

            # Player 2 Pad Type
            if system.isOptSet('p2_pad'):
                rpcs3plusConfig.set("Controls", "player_1_type", system.config["p2_pad"])
            else:
                rpcs3plusConfig.set("Controls", "player_1_type", "0")
            
            # Player 3 Pad Type
            if system.isOptSet('p3_pad'):
                rpcs3plusConfig.set("Controls", "player_2_type", system.config["p3_pad"])
            else:
                rpcs3plusConfig.set("Controls", "player_2_type", "0")

            # Player 4 Pad Type
            if system.isOptSet('p4_pad'):
                rpcs3plusConfig.set("Controls", "player_3_type", system.config["p4_pad"])
            else:
                rpcs3plusConfig.set("Controls", "player_3_type", "0")

            
            rpcs3plusConfig.set("Controls", "player_1_type\default", "false")

            rpcs3plusConfig.set("Controls", "vibration_enabled", "true")
            rpcs3plusConfig.set("Controls", "vibration_enabled\\default", "true")

            guidstoreplace_ds4 = ["050000004c050000c405000000783f00","050000004c050000c4050000fffe3f00","050000004c050000c4050000ffff3f00","050000004c050000cc090000fffe3f00","050000004c050000cc090000ffff3f00","30303839663330346632363232623138","31326235383662333266633463653332","34613139376634626133336530386430","37626233336235343937333961353732","38393161636261653636653532386639","63313733393535663339656564343962","63393662363836383439353064663939","65366465656364636137653363376531","66613532303965383534396638613230","050000004c050000cc090000df070000","050000004c050000cc090000df870001","050000004c050000cc090000ff070000","030000004c050000a00b000011010000","030000004c050000a00b000011810000","030000004c050000c405000011010000","030000004c050000c405000011810000","030000004c050000cc09000000010000","030000004c050000cc09000011010000","030000004c050000cc09000011810000","03000000c01100000140000011010000","050000004c050000c405000000010000","050000004c050000c405000000810000","050000004c050000c405000001800000","050000004c050000cc09000000010000","050000004c050000cc09000000810000","050000004c050000cc09000001800000","030000004c050000a00b000000010000","030000004c050000c405000000000000","030000004c050000c405000000010000","03000000120c00000807000000000000","03000000120c0000111e000000000000","03000000120c0000121e000000000000","03000000120c0000130e000000000000","03000000120c0000150e000000000000","03000000120c0000180e000000000000","03000000120c0000181e000000000000","03000000120c0000191e000000000000","03000000120c00001e0e000000000000","03000000120c0000a957000000000000","03000000120c0000aa57000000000000","03000000120c0000f21c000000000000","03000000120c0000f31c000000000000","03000000120c0000f41c000000000000","03000000120c0000f51c000000000000","03000000120c0000f70e000000000000","03000000120e0000120c000000000000","03000000160e0000120c000000000000","030000001a1e0000120c000000000000","030000004c050000a00b000000000000","030000004c050000cc09000000000000","35643031303033326130316330353564","31373231336561636235613666323035","536f6e7920496e746572616374697665","576972656c65737320436f6e74726f6c","050000004c050000cc090000ff870001","050000004c050000cc090000ff876d01","31663838336334393132303338353963"]
            guidstoreplace_ds5_wireless = ["32633532643734376632656664383733","37363764353731323963323639666565","61303162353165316365336436343139","050000004c050000e60c0000df870000","050000004c050000e60c000000810000","030000004c050000e60c000000010000","050000004c050000e60c0000fffe3f00","030000004c050000e60c000000000000","050000004c050000e60c000000010000","030000004c050000e60c000011010000","32346465346533616263386539323932","050000004c050000e60c0000ff870000"]
            guidstoreplace_ds5_wired = ["030000004c050000e60c000011810000"]
            guidstoreplace_xbox = ["050000005e040000fd02000030110000"]
            guidstoreplace_steam = ["03000000de2800000512000010010000"]
            guidstoreplace_steam2 = ["03000000de2800000512000011010000"]

            cguid = [0 for x in range(10)]
            lastplayer = 0
            for index in playersControllers :
                controller = playersControllers[index]
                portnumber = cguid.count(controller.guid)
                controllernumber = str(int(controller.player) - 1)
                cguid[int(controllernumber)] = controller.guid
                inputguid = controller.guid
                #DS4 GUIDs from https://github.com/gabomdq/SDL_GameControllerDB/blob/master/gamecontrollerdb.txt
                if controller.guid in guidstoreplace_ds4:
                    inputguid = "030000004c050000cc09000000006800"
                #DS5 GUIDs from https://github.com/gabomdq/SDL_GameControllerDB/blob/master/gamecontrollerdb.txt
                if controller.guid in guidstoreplace_ds5_wireless:
                    inputguid = "030000004c050000e60c000000006800"
                if controller.guid in guidstoreplace_ds5_wired:
                    inputguid = "030000004c050000e60c000000016800"
                if controller.guid in guidstoreplace_xbox:
                    inputguid = "050000005e040000fd02000030110000"
                #DS5 corrections
                if ((controller.guid in guidstoreplace_ds5_wireless) or (controller.guid in guidstoreplace_ds4) or (controller.guid in guidstoreplace_ds5_wired)) :
                    #button_a="engine:sdl,port:0,guid:030000004c050000e60c000000006800,button:1"
                    for x in rpcs3plusDSButtons:
                        rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},button:{}"'.format(portnumber,inputguid,rpcs3plusDSButtons[x]))
                    for x in rpcs3plusDSAxis:
                        if(x == "button_zl" or x == "button_zr"):
                            rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,invert:+,port:{},guid:{},axis:{},threshold:0.500000"'.format(portnumber,inputguid,rpcs3plusDSAxis[x]))
                        else:
                            rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},axis_x:{},offset_x:-0.011750,axis_y:{},offset_y:-0.027467,invert_x:+,invert_y:+,deadzone:0.150000,range:0.950000"'.format(portnumber,inputguid,rpcs3plusDSAxis[x],rpcs3plusDSAxis[x]+1))
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                elif (controller.guid in guidstoreplace_steam) :
                    #button_a="engine:sdl,port:0,guid:030000004c050000e60c000000006800,button:1"
                    for x in rpcs3plusSCButtons:
                        rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},button:{}"'.format(portnumber,inputguid,rpcs3plusSCButtons[x]))
                    for x in rpcs3plusSCAxis:
                        if(x == "button_zl" or x == "button_zr"):
                            rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,invert:+,port:{},guid:{},axis:{},threshold:0.500000"'.format(portnumber,inputguid,rpcs3plusSCAxis[x]))
                        else:
                            rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},axis_x:{},offset_x:-0.011750,axis_y:{},offset_y:-0.027467,invert_x:+,invert_y:+,deadzone:0.150000,range:0.950000"'.format(portnumber,inputguid,rpcs3plusSCAxis[x],rpcs3plusSCAxis[x]+1))
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"[empty]"')
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"[empty]"')
                    #rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                    #rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                elif (controller.guid in guidstoreplace_steam2) :
                    #button_a="engine:sdl,port:0,guid:030000004c050000e60c000000006800,button:1"
                    for x in rpcs3plusSCButtons2:
                        rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},button:{}"'.format(portnumber,inputguid,rpcs3plusSCButtons2[x]))
                    for x in rpcs3plusSCAxis2:
                        if(x == "button_zl" or x == "button_zr"):
                            rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,invert:+,port:{},guid:{},axis:{},threshold:0.500000"'.format(portnumber,inputguid,rpcs3plusSCAxis2[x]))
                        else:
                            rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"engine:sdl,port:{},guid:{},axis_x:{},offset_x:-0.011750,axis_y:{},offset_y:-0.027467,invert_x:+,invert_y:+,deadzone:0.150000,range:0.950000"'.format(portnumber,inputguid,rpcs3plusSCAxis2[x],rpcs3plusSCAxis2[x]+1))
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"[empty]"')
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"[empty]"')
                    #rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                    #rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionright", '"engine:sdl,motion:0,port:{},guid:{}"'.format(portnumber,inputguid))
                else:
                    for x in rpcs3plusButtons:
                        rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"{}"'.format(RPCS3PLUSGenerator.setButton(rpcs3plusButtons[x], inputguid, controller.inputs,portnumber)))
                    for x in rpcs3plusAxis:
                        rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '"{}"'.format(RPCS3PLUSGenerator.setAxis(rpcs3plusAxis[x], inputguid, controller.inputs, portnumber)))
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionleft", '[empty]')
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_motionright", '[empty]')

                
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_connected", "true")
                if (controllernumber == "0"):
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_connected\default", "true")
                else:
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_connected\default", "false")                    
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_type", "0")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_type\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_vibration_enabled", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_vibration_enabled\\default", "true")
                lastplayer = int(controllernumber)
            lastplayer = lastplayer + 1
            eslog.debug("Last Player {}".format(lastplayer))
            for y in range(lastplayer, 9):
                controllernumber = str(y)
                eslog.debug("Setting Controller: {}".format(controllernumber))
                for x in rpcs3plusButtons:
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '""')
                for x in rpcs3plusDSAxis:
                    rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_" + x, '""')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_a", '"toggle:0,code:67,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_a\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_b", '"toggle:0,code:88,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_b\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_ddown", '"toggle:0,code:16777237,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_ddown\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_dleft", '"toggle:0,code:16777234,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_dleft\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_dright", '"toggle:0,code:16777236,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_dright\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_dup", '"toggle:0,code:16777235,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_dup\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_home", '"toggle:0,code:0,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_home\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_l", '"toggle:0,code:81,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_l\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_lstick", '"toggle:0,code:70,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_lstick\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_minus", '"toggle:0,code:78,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_minus\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_plus", '"toggle:0,code:77,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_plus\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_r", '"toggle:0,code:69,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_r\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_rstick", '"toggle:0,code:71,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_rstick\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_screenshot", '"toggle:0,code:0,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_screenshot\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_sl", '"toggle:0,code:81,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_sl\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_sr", '"toggle:0,code:69,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_sr\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_x", '"toggle:0,code:86,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_x\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_y", '"toggle:0,code:90,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_y\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_zl", '"toggle:0,code:82,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_zl\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_zr", '"toggle:0,code:84,engine:keyboard"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_button_zr\\default", "true")

                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_lstick", '"modifier_scale:0.500000,modifier:toggle$00$1code$016777248$1engine$0keyboard,right:toggle$00$1code$068$1engine$0keyboard,left:toggle$00$1code$065$1engine$0keyboard,down:toggle$00$1code$083$1engine$0keyboard,up:toggle$00$1code$087$1engine$0keyboard,engine:analog_from_button"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_lstick\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_rstick", '"modifier_scale:0.500000,modifier:toggle$00$1code$00$1engine$0keyboard,right:toggle$00$1code$076$1engine$0keyboard,left:toggle$00$1code$074$1engine$0keyboard,down:toggle$00$1code$075$1engine$0keyboard,up:toggle$00$1code$073$1engine$0keyboard,engine:analog_from_button"')
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_rstick\\default", "true")


                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_connected", "false")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_connected\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_type", "0")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_type\\default", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_vibration_enabled", "true")
                rpcs3plusConfig.set("Controls", "player_" + controllernumber + "_vibration_enabled\\default", "true")


    # telemetry section
        if not rpcs3plusConfig.has_section("WebService"):
            rpcs3plusConfig.add_section("WebService") 
        rpcs3plusConfig.set("WebService", "enable_telemetry", "false")
        rpcs3plusConfig.set("WebService", "enable_telemetry\\default", "false") 
        
        
    # Services section
        if not rpcs3plusConfig.has_section("Services"):
            rpcs3plusConfig.add_section("Services")
        rpcs3plusConfig.set("Services", "bcat_backend", "none")
        rpcs3plusConfig.set("Services", "bcat_backend\\default", "none") 

        ### update the configuration file
        if not os.path.exists(os.path.dirname(rpcs3plusConfigFile)):
            os.makedirs(os.path.dirname(rpcs3plusConfigFile))
        with open(rpcs3plusConfigFile, 'w') as configfile:
            rpcs3plusConfig.write(configfile)

        with open(beforerpcs3plusConfigFile, 'w') as configfile:
            rpcs3plusConfig.write(configfile)

    @staticmethod
    def setButton(key, padGuid, padInputs,controllernumber):

        # it would be better to pass the joystick num instead of the guid because 2 joysticks may have the same guid
        if key in padInputs:
            input = padInputs[key]

            if input.type == "button":
                return ("engine:sdl,button:{},guid:{},port:{}").format(input.id, padGuid, controllernumber)
            elif input.type == "hat":
                return ("engine:sdl,hat:{},direction:{},guid:{},port:{}").format(input.id, RPCS3PLUSGenerator.hatdirectionvalue(input.value), padGuid, controllernumber)
            elif input.type == "axis":
                # untested, need to configure an axis as button / triggers buttons to be tested too
                return ("engine:sdl,threshold:{},axis:{},guid:{},port:{},invert:{}").format(0.5, input.id, padGuid, controllernumber, "+")
                

    @staticmethod
    def setAxis(key, padGuid, padInputs,controllernumber):
        inputx = -1
        inputy = -1

        if key == "joystick1":
            try:
                inputx = padInputs["joystick1left"]
            except:
                inputx = ["0"]
        elif key == "joystick2":
            try:
                inputx = padInputs["joystick2left"]
            except:
                inputx = ["0"]

        if key == "joystick1":
            try:
                inputy = padInputs["joystick1up"]
            except:
                inputy = ["0"]
        elif key == "joystick2":
            try:
                inputy = padInputs["joystick2up"]
            except:
                inputy = ["0"]

        try:
            return ("engine:sdl,range:1.000000,deadzone:0.100000,invert_y:+,invert_x:+,offset_y:-0.000000,axis_y:{},offset_x:-0.000000,axis_x:{},guid:{},port:{}").format(inputy.id, inputx.id, padGuid, controllernumber)
        except:
            return ("0")

    @staticmethod
    def hatdirectionvalue(value):
        if int(value) == 1:
            return "up"
        if int(value) == 4:
            return "down"
        if int(value) == 2:
            return "right"
        if int(value) == 8:
            return "left"
        return "unknown"